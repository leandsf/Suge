<?php
	include ('conexao_comum.php');
	$nome_do_cliente = $_POST['nome_do_cliente'];
	$data_da_consulta = $_POST['data_da_consulta'];
	$cliente_cpf = $_POST['cliente_cpf'];
	include "menu.php";
	$sql ="SELECT b.nome_do_cliente, b.cliente_cpf, a.assunto_da_consulta, a.data_da_consulta
	FROM consultas a INNER JOIN clientes b ON a.cliente_id=b.cliente_id WHERE b.nome_do_cliente
	LIKE '%{$nome_do_cliente}%' AND b.cliente_cpf LIKE '%{$cliente_cpf}%' AND a.data_da_consulta
	LIKE '%{$data_da_consulta}%'";
	$query = $conn->query($sql);
	while ($dados = $query->fetch_array()) {
	  echo  'Nome do cliente: ' . $dados['nome_do_cliente'] . ' <br>';
	  echo 'CPF do cliente: ' . $dados['cliente_cpf'] . ' <br>';
	  echo 'Assunto da consulta: ' . $dados['assunto_da_consulta'] . ' <br>';
	  echo 'Data da consulta: ' . $dados['data_da_consulta'] . ' <br>';
	  echo '<br> <br>';
	}
	echo 'Registros encontrados: ' . $query->num_rows;

?>
