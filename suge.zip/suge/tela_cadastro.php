calendario<?php require "verifica.php";
include "conexao_comum.php";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="shortcut icon" href="redlogo.png" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    <title>SUGE</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/startmin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="navbar-header">
            <a class="navbar-brand" href="suge.php" >
                <img src="logo.png" style="width:60px;height:40px;border:0;margin-top: -10px; margin-left: 20px;">
            </a>
        </div>

        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>

        <!-- Top Navigation: Left Menu -->


        <!-- Top Navigation: Right Menu -->
        <ul class="nav navbar-right navbar-top-links">

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="fa fa-user fa-fw"></i><b class="caret"></b>
                </a>
                <ul class="dropdown-menu dropdown-user">
                  <li>
                    <a>
                      <?php
                      	echo "Usuario: ". $_SESSION['nome_do_usuario'];
                      ?>
                    </a>
                  </li>
                    <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i>Sair</a>
                    </li>
                </ul>
            </li>
        </ul>

        <!-- Sidebar -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">

                <ul class="nav" id="side-menu">

                    <li>
                        <a href="tela_cadastro.php">Novo Cliente<span class="fa arrow"></span></a>
                    </li>
                    <li>
                        <a href="tela_consulta.php">Nova Consulta<span class="fa arrow"></span> </a>
                    </li>
                    <li>
                        <a href="tela_registro.php">Registros<span class="fa arrow"></span> </a>
                    </li>
                    <li>
                        <a href="calendario/index.php">Calendário<span class="fa arrow"></span></a>
                    </li>
                    <li>
                      <a href="att_status_consulta.php">Atualizar status da consulta<span class="fa arrow"></span></a>
                    </li>
                </ul>

            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="page-wrapper">

        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">

                </div>
            </div>
                    <div class="col-lg-12">
                        <h1 class="page-header">Realizar cadastro</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Informações do Cliente
                            </div>

                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <form role="form" action="conexao_cadastrar_clientes.php" method="post">
                                            <div class="form-group">
                                                <label>Nome Completo</label>
                                                <input class="form-control" type="text" name="nome_do_cliente">

                                            </div>

                                            <div class="form-group" >
                                                <label>Nome do Completo do Pai</label>
                                                <input class="form-control" type="text" name="pai_do_cliente">

                                            </div>
                                            <div class="form-group">
                                                <label>Nome do Completo da Mãe</label>
                                                <input class="form-control" type="text" name="mae_do_cliente">

                                            </div>
                                            <div class="form-group">
                                                <label>CPF</label>
                                                <input class="form-control" type="text" name="cliente_cpf">

                                            </div>
                                            <div class="form-group">
                                                <label>RG</label>
                                                <input class="form-control" type="text" name="cliente_rg">

                                            </div>
                                            <div class="form-group">
                                                <label>Data de Nascimento</label></br>
                                                    <input type="date" name="data_de_nascimento_do_cliente">
                                                </label>
                                            <div class="form-group">
                                                <label>E-mail</label>
                                                <input class="form-control" placeholder="" type="text" name="cliente_email">
                                            </div>
                                            <div class="form-group">
                                                <label>Telefone</label></br>
                                                <input id="phonenum" type="tel"  name="cliente_telefone" pattern="^\d{2}-\d{5}-\d{4}$" placeholder="(yy) xxxxx-xxxx"required >
                                            </div>
                                            <button type="submit" class="btn btn-default" value="Cadastrar">Submeter</button>
                                            <a href="tela_cadastro.php"><button type="reset" class="btn btn-default">Limpar</button></a>
                                        </form>
                                        <?php
            if(isset($_SESSION['status_cli'])){
                  echo "<a id='msg'>" . $_SESSION['status_cli'] . "</a>";
                  unset($_SESSION['status_cli']);
            }
      ?>
      <script>
      setTimeout(function(){
      $('#msg').remove();
      }, 3000);
      </script>
                                    </div>
                                    <!-- /.col-lg-6 (nested) -->


            <!-- ... Your content goes here ... -->

        </div>
    </div>

</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="js/startmin.js"></script>

</body>
</html>
