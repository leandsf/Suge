<?php
	session_start();
	include ('conexao_comum.php');
	$nome_do_cliente = $_POST['nome_do_cliente'];
	$pai_do_cliente= $_POST['pai_do_cliente'];
	$mae_do_cliente= $_POST['mae_do_cliente'];
	$cliente_cpf= $_POST['cliente_cpf'];
	$cliente_rg= $_POST['cliente_rg'];
	$data_de_nascimento_do_cliente= $_POST['data_de_nascimento_do_cliente'];
	$cliente_email= $_POST['cliente_email'];
	$cliente_telefone= $_POST['cliente_telefone'];
	if (mysqli_connect_error()){
	  die('Connect Error ('. mysqli_connect_errno() .') '
		. mysqli_connect_error());
	}
	else{
		$conn->query("INSERT INTO clientes (nome_do_cliente, pai_do_cliente, mae_do_cliente, cliente_cpf,
                      cliente_rg, data_de_nascimento_do_cliente, cliente_email, cliente_telefone)
			    VALUES ('$nome_do_cliente', '$pai_do_cliente', '$mae_do_cliente', '$cliente_cpf',
		'$cliente_rg', '$data_de_nascimento_do_cliente', '$cliente_email', '$cliente_telefone')");
		if ($conn==true){
			$_SESSION['status_cli'] = "";
			header("Location: cliente_cadastro_confirma.php");
		}
		else{
			$_SESSION['status_cli'] = "Erro: ". $conn ."
			". $conn->error;
			header("Location: cadastrar_clientes.php");
		}
		  $conn->close();
		}
?>
