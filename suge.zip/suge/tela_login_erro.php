<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <link rel="shortcut icon" href="redlogo.png" />
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>SUGE-login</title>

        <!-- Bootstrap Core CSS -->
        <link href="./css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="./css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="./css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="./css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <style >
        .esquerda{
            padding:8px;
            float: left;
            margin-left: 200px;
            position: center;
            margin-top: 150px;
        }
        h1{
            font-size: 25px;
            margin-top: -10px;
            color: #0070BC;
        }
        .erro{
            background-color: #A52A2A;
            color: white;
            padding: 6px 10px;
            border-radius: 4px;
            left: 0px;
            margin: 0px;
            width: 100%;
            border-left: 0px;
            position: fixed; left;
            top:0;
        }
    </style>
    </head>
    <body>

        <div class="container">
              <div class="erro" align="center" style type="text/css "font-family="Helvetica,Arial">
                 <label>Usuário e(ou) senha incorreto. Por Favor, tente novamente!</label>
            </div>
            <div class="row">
                <div class="esquerda" align="center">
                    <div  class="img_suge" ></br></br></br></br></br></br>
                        <img src="logo_suge.png"  height="127" width="206px">
                    </div>
                    <div  class="subtitulo" >
                        <h1>Sistema Unificado de<br>Gestão para Escritórios</h1>
                    </div>
                </div>
                <div class="col-md-4 col-md-offset-4">
                </br></br></br></br></br></br></br></br>
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title" align="center">Entrar</h3>
                        </div>
                        <div class="panel-body">
                            <form role="form" action="conexao_login.php" method="post">
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="E-mail" name="email_do_usuario" type="text"  autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Senha" name="senha_do_usuario" type="password" value="">
                                    </div>

                                    <!-- Change this to a button or input when using this as a form -->
                                    <input class="btn btn-lg btn-success btn-block" type="submit" value="Entrar">

                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- jQuery -->
        <script src="./js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="./js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="./js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="./js/startmin.js"></script>

    </body>
</html>
