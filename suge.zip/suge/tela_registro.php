<!-- Conexão php -->
<?php require "verifica.php";
include "conexao_comum.php";
?>
<!-- Predefinições do documento -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <link rel="shortcut icon" href="redlogo.png" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Importação do bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/metisMenu.min.css" rel="stylesheet">
  <link href="css/timeline.css" rel="stylesheet">
  <link href="css/startmin.css" rel="stylesheet">
  <link href="css/morris.css" rel="stylesheet">
  <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <title>SUGE</title>
</head>
<body>
  <!-- Barra do topo - botão menu e logout -->
  <div id="wrapper">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="navbar-header">
        <a class="navbar-brand" href="suge.php" >
          <img src="logo.png" style="width:60px;height:40px;border:0;margin-top: -10px; margin-left: 20px;">
        </a>
      </div>
      <ul class="nav navbar-right navbar-top-links">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-user fa-fw"></i><b class="caret"></b>
          </a>
          <ul class="dropdown-menu dropdown-user">
            <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i>Sair</a>
            </li>
          </ul>
        </li>
      </ul>
    </div>

    <!-- Menu Lateral -->
    <div class="navbar-default sidebar" role="navigation">
      <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
          <li>
            <a href="tela_cadastro.php">Novo Cliente<span class="fa arrow"></span></a>
          </li>
          <li>
            <a href="tela_consulta.php">Nova Consulta<span class="fa arrow"></span> </a>
          </li>
          <li>
            <a href="tela_registro.php">Registros<span class="fa arrow"></span> </a>
          </li>
          <li>
            <a href="calendario/index.php">Calendário<span class="fa arrow"></span></a>
          </li>
          <li>
            <a href="att_status_consulta.php">Atualizar status da consulta<span class="fa arrow"></span></a>
          </li>		
        </ul>
      </div>
    </div>
  </nav>

  <!-- Conteúdo principal da página -->
  <div id="page-wrapper">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
        </div>
      </div>
      <div class="col-lg-12">
        <h1 class="page-header">Buscar Registros</h1>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            Informações do para busca
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-lg-6">
                <form role="form" action="registro_resultado.php" method="post">
                  <div class="form-group">
                    <label>Nome do Cliente</label>
                    <input class="form-control" type="text" name="nome_do_cliente">
                  </div>
                  <div class="form-group">
                    <label>CPF do Cliente</label>
                    <input class="form-control" type="text" name="cliente_cpf">
                  </div>
                  <div class="form-group">
                    <label>Data da Consulta</label>
                    <input class="form-control" type="date" name="data_da_consulta">
                  </div>
                  <button type="submit" class="btn btn-default">Buscar todos</button>
                </form>
              </div>
            </div>
          </div>
        </div>

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

      </body>
      </html>
