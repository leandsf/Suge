<?php
	session_start();
	include ('conexao_comum.php');
	$cliente = $_POST['cliente_id'];
	$data_da_consulta = $_POST['data_da_consulta'];
	$hora_da_consulta = $_POST['hora_da_consulta'];
	$assunto_da_consulta = $_POST['assunto_da_consulta'];
	$status_da_consulta = $_POST['status_da_consulta'];

	if (mysqli_connect_error()){
	  die('Connect Error ('. mysqli_connect_errno() .') '
		. mysqli_connect_error());
	}
	else{
		$conn->query("INSERT INTO consultas (data_da_consulta, hora_da_consulta, cliente_id, assunto_da_consulta, status_da_consulta)
		VALUES ('$data_da_consulta','$hora_da_consulta','$cliente','$assunto_da_consulta','$status_da_consulta')");
		if ($conn==true){
			$_SESSION['status'] = "";
			header("Location: cliente_consulta_confirma.php");
		}
		else{
			$_SESSION['status'] = "Erro: ". $sql ."
			". $conn->error;
			header("Location: cadastrar_consultas.php");
		}
		  $conn->close();
		}
?>
