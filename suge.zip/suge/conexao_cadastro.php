<?php
	$nome_do_usuario = filter_input(INPUT_POST, 'nome_do_usuario');
	$email_do_usuario = filter_input(INPUT_POST, 'email_do_usuario');
	$senha_do_usuario = md5 (filter_input (INPUT_POST, 'senha_do_usuario'));
	if (!empty($_POST['nome_do_usuario'])){
		if (!empty($_POST['senha_do_usuario'])){
			if (!empty($_POST['email_do_usuario'])){
				$host = "localhost";
				$dbusername = "root";
				$dbpassword = "";
				$dbname = "SUGE";
				// Create connection
				$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
				if (mysqli_connect_error()){
				  die('Connect Error ('. mysqli_connect_errno() .') '
					. mysqli_connect_error());
				}
				else{
				  $sql = "INSERT INTO usuarios (nome_do_usuario, email_do_usuario, senha_do_usuario)
				  values ('$nome_do_usuario','$email_do_usuario','$senha_do_usuario')";
				  if ($conn->query($sql)){
					header("Location: tela_cadastro_sucesso.php");
				  }
				  else{
					echo "Erro: ". $sql ."
				". $conn->error;
				  }
				  $conn->close();
				}
			}
			else{
				header("Location: tela_cadastro_erro.php");
				die();
			}
		}
		else{
			header("Location: tela_cadastro_erro.php");
			die();
		}
	}
	else{
		header("Location: tela_cadastro_erro.php");
		die();
	}
?>
