<?php
// Incluir aquivo de conexão
include("conexao_comum.php");
// Acentuação
header("Content-Type: text/html; charset=UTF-8",true);

// Recebe o valor enviado
$valor = $_GET['valor'];

// Procura titulos no banco relacionados ao valor
$sql = $conn->query("SELECT b.consulta_id,a.cliente_id,a.nome_do_cliente,a.mae_do_cliente,a.cliente_cpf,b.data_da_consulta,b.hora_da_consulta,b.status_da_consulta FROM clientes a INNER JOIN consultas b ON a.cliente_id=b.cliente_id WHERE
	b.data_da_consulta LIKE '%".$valor."%' LIMIT 50");


// Exibe todos os valores encontrados

while ($clientes = $sql->fetch_array()) {
	echo '<option value=" '.$clientes["consulta_id"].' ">
	Nome: '.$clientes["nome_do_cliente"].' | Mãe: '.$clientes["mae_do_cliente"].' | CPF: '.$clientes["cliente_cpf"].' | Data: '.$clientes["data_da_consulta"].' | Hora: '.$clientes["hora_da_consulta"].' | Status: '.$clientes["status_da_consulta"].'</option>';
}
?>
