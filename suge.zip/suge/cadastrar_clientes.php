<?php require "verifica.php";
include "conexao_comum.php";
?>

<!DOCTYPE html>
<html>
<head>
      <script type="text/javascript" src="funcs.js"></script>
</head>
<body>
      <?php include "menu.php" ?>
      <form name="input" action="conexao_cadastrar_clientes.php" method="post">
          <a>nome do cliente<a> <input type="text" name="nome_do_cliente"><br><br>
          <a>nome do pai<a> <input type="text" name="pai_do_cliente"><br><br>
          <a>nome da mãe<a> <input type="text" name="mae_do_cliente"><br><br>
          <a>cpf do cliente<a> <input type="text" name="cliente_cpf"><br><br>
          <a>rg do cliente<a> <input type="text" name="cliente_rg"><br><br>
          <a>data de nascimento<a> <input type="date" name="data_de_nascimento_do_cliente"><br><br>
          <a>email: <a> <input type="text" name="cliente_email"><br><br>
          <a>telefone: <a> <input type="text" name="cliente_telefone"><br><br>
          <input type="submit" value="Cadastrar">
      </form>
      <?php
            if(isset($_SESSION['status_cli'])){
                  echo "<a id='msg'>" . $_SESSION['status_cli'] . "</a>";
                  unset($_SESSION['status_cli']);
            }
      ?>
      <script>
      setTimeout(function(){
      $('#msg').remove();
      }, 3000);
      </script>
</body>
</html>
