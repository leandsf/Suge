<?php
	session_start();
	include ('conexao_comum.php');
	$cliente = $_POST['consulta_id'];
	$data_da_consulta = $_POST['data_da_consulta'];
	$hora_da_consulta = $_POST['hora_da_consulta'];
	$assunto_da_consulta = $_POST['assunto_da_consulta'];
	$status_da_consulta = $_POST['status_da_consulta'];

	if (mysqli_connect_error()){
	  die('Connect Error ('. mysqli_connect_errno() .') '
		. mysqli_connect_error());
	}
	else{
		$conn->query("UPDATE consultas SET status_da_consulta='$status_da_consulta' WHERE consulta_id='$cliente'");
		if ($conn==true){
			$_SESSION['status'] = "";
			header("Location: atualiza_consulta_confirma.php");
		}
		else{
			$_SESSION['status'] = "Erro: ". $sql ."
			". $conn->error;
			header("Location: cadastrar_consultas.php");
		}
		  $conn->close();
		}
?>
