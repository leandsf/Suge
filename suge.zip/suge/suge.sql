CREATE Database suge;
USE suge;
-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07-Dez-2018 às 13:32
-- Versão do servidor: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `suge`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `cliente_id` int(11) NOT NULL,
  `nome_do_cliente` varchar(100) DEFAULT NULL,
  `data_de_nascimento_do_cliente` date DEFAULT NULL,
  `cliente_cpf` varchar(11) DEFAULT NULL,
  `cliente_rg` varchar(9) DEFAULT NULL,
  `mae_do_cliente` varchar(100) DEFAULT NULL,
  `pai_do_cliente` varchar(100) DEFAULT NULL,
  `cliente_telefone` varchar(11) DEFAULT NULL,
  `cliente_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`cliente_id`, `nome_do_cliente`, `data_de_nascimento_do_cliente`, `cliente_cpf`, `cliente_rg`, `mae_do_cliente`, `pai_do_cliente`, `cliente_telefone`, `cliente_email`) VALUES
(1, 'vitoria', NULL, '12345678910', NULL, 'Maria', NULL, NULL, NULL),
(2, 'leandro', NULL, '12345678911', NULL, 'Joaquina', NULL, NULL, NULL),
(3, 'carol', NULL, '12345678912', NULL, 'Belarmina', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `consultas`
--

CREATE TABLE `consultas` (
  `consulta_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `assunto_da_consulta` varchar(500) DEFAULT NULL,
  `status_da_consulta` varchar(20) DEFAULT NULL,
  `data_da_consulta` date DEFAULT NULL,
  `hora_da_consulta` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `consultas`
--

INSERT INTO `consultas` (`consulta_id`, `usuario_id`, `cliente_id`, `assunto_da_consulta`, `status_da_consulta`, `data_da_consulta`, `hora_da_consulta`) VALUES
(1, NULL, 1, 'dor de barriga', NULL, NULL, NULL),
(2, NULL, 1, 'exames de rotina', NULL, NULL, NULL),
(3, NULL, 2, 'dor na coluna', NULL, NULL, NULL),
(4, NULL, 2, 'retorno da consulta de dor na coluna', NULL, NULL, NULL),
(5, NULL, 3, 'probleminhas na cabeca', '$status_da_consulta', NULL, NULL),
(6, NULL, 3, 'rinoplastia', NULL, NULL, NULL),
(7, NULL, 3, 'remover curativos', NULL, NULL, NULL),
(8, NULL, 1, 'DSADSADA', 'Realizada', NULL, NULL),
(9, NULL, 1, 'aaaaaaaaaaaaaaaa', 'Cancelada', NULL, NULL),
(10, NULL, 1, 'oijaidosad', 'Pendente', '2018-12-29', '14:00:00'),
(11, NULL, 3, 'asdjnsaidjsad', 'Pendente', '2018-12-29', '15:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 NOT NULL,
  `color` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `events`
--

INSERT INTO `events` (`id`, `title`, `color`, `start`, `end`) VALUES
(1, 'carol', '', '2018-12-12 00:00:00', '2018-12-13 00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario_id` int(11) NOT NULL,
  `nome_do_usuario` varchar(100) DEFAULT NULL,
  `email_do_usuario` varchar(100) DEFAULT NULL,
  `senha_do_usuario` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `nome_do_usuario`, `email_do_usuario`, `senha_do_usuario`) VALUES
(2, 'Ana Evanilde da Silva Barboza', 'anaevanilde@gmail.com', '202cb962ac59075b964b07152d234b70'),
(3, 'leandro', 'leandro.sf@outlook.com.br', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cliente_id`);

--
-- Indexes for table `consultas`
--
ALTER TABLE `consultas`
  ADD PRIMARY KEY (`consulta_id`),
  ADD KEY `fk_clientes` (`cliente_id`),
  ADD KEY `fk_usuarios` (`usuario_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `cliente_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `consultas`
--
ALTER TABLE `consultas`
  MODIFY `consulta_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `consultas`
--
ALTER TABLE `consultas`
  ADD CONSTRAINT `fk_clientes` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`),
  ADD CONSTRAINT `fk_usuarios` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
