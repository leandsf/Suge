<?php
// Incluir aquivo de conexão
include("conexao_comum.php");
// Acentuação
header("Content-Type: text/html; charset=UTF-8",true);

// Recebe o valor enviado
$valor = $_GET['valor'];

// Procura titulos no banco relacionados ao valor
$sql = $conn->query("SELECT  cliente_id,nome_do_cliente,mae_do_cliente,cliente_cpf FROM clientes WHERE
	nome_do_cliente LIKE '%".$valor."%' LIMIT 20");

// Exibe todos os valores encontrados

while ($clientes = $sql->fetch_array()) {
	echo '<option value=" '.$clientes["cliente_id"].' ">
	Nome: '.$clientes["nome_do_cliente"].' | Mãe: '.$clientes["mae_do_cliente"].' | CPF: '.$clientes["cliente_cpf"].'</option>';
}

?>
